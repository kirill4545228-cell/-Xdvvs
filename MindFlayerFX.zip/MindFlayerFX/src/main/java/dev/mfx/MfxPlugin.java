package dev.mfx;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.logging.Level;

public final class MfxPlugin extends JavaPlugin implements TabExecutor {

    public record Def(String id, String desc, int period, Supplier<Fx> make) {}

    static final Map<String, Def> DEFS = new LinkedHashMap<>();

    private static void reg(String id, String desc, int period, Supplier<Fx> make) {
        DEFS.put(id, new Def(id, desc, period, make));
    }

    static {
        reg("sphere", "Огромный шар из зелёных и жёлтых потоков частиц вокруг невидимой точки", 2, SphereFx::new);
        reg("mindflayer", "Истязатель разума: тело-капля и 8 ног, по ним текут частицы", 2, MindFlayerFx::new);
        reg("galaxy", "Вращающаяся спиральная галактика с ядром", 2, Effects.Galaxy::new);
        reg("rift", "Разлом в Изнанку: кровавое кольцо, воронка и молнии-щупальца", 2, Effects.Rift::new);
        reg("tornado", "Гигантский торнадо", 2, Effects.Tornado::new);
        reg("dna", "Двойная спираль ДНК с перекладинами", 2, Effects.Dna::new);
        reg("blackhole", "Чёрная дыра: аккреционный диск, джеты, фотонное кольцо", 2, Effects.Hole::new);
        reg("phoenix", "Феникс кружит в небе и машет огненными крыльями", 2, Effects.Phoenix::new);
        reg("supernova", "Цикл сверхновой: коллапс, вспышка, ударные оболочки", 2, Effects.Supernova::new);
        reg("storm", "Грозовая туча, дождь и фрактальные молнии", 2, Effects.Storm::new);
        reg("knot", "Радужный трилистник-узел, по которому текут частицы", 2, Effects.Knot::new);
        reg("aurora", "Северное сияние: двойные колышущиеся занавесы", 3, Effects.Aurora::new);
    }

    private final Map<Integer, Run> runs = new LinkedHashMap<>();
    private int nextId = 1;

    private final class Run implements Runnable {
        final int id;
        final Def def;
        final World w;
        final double x, y, z, s;
        final Fx fx;
        final int max;
        int t = 0;
        BukkitTask task;

        Run(int id, Def def, World w, double x, double y, double z, double s, int max) {
            this.id = id; this.def = def; this.w = w; this.x = x; this.y = y; this.z = z;
            this.s = s; this.max = max; this.fx = def.make().get();
        }

        @Override
        public void run() {
            if (t >= max || Bukkit.getWorld(w.getUID()) == null) {
                stop(id);
                return;
            }
            try {
                double density = getConfig().getDouble("density", 1.0);
                fx.tick(new Ctx(w, x, y, z, s, density, t, t / def.period()));
            } catch (Throwable e) {
                getLogger().log(Level.SEVERE, "Ошибка в эффекте " + def.id(), e);
                stop(id);
                return;
            }
            t += def.period();
        }
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (getCommand("mfx") != null) getCommand("mfx").setExecutor(this);
        getLogger().info("MindFlayerFX включён. Эффектов: " + DEFS.size());
    }

    @Override
    public void onDisable() {
        stopAll();
    }

    private void stop(int id) {
        Run r = runs.remove(id);
        if (r != null && r.task != null) r.task.cancel();
    }

    private void stopAll() {
        for (Integer id : new ArrayList<>(runs.keySet())) stop(id);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage("§e/mfx list §7- список анимаций");
            sender.sendMessage("§e/mfx play <имя> [масштаб] [секунд] §7- запуск в вашей точке (0 секунд = бесконечно)");
            sender.sendMessage("§e/mfx active §7- запущенные");
            sender.sendMessage("§e/mfx stop <id|all> §7- остановить");
            return true;
        }
        String sub = args[0].toLowerCase();
        if (sub.equals("list")) {
            for (Def d : DEFS.values()) sender.sendMessage("§a" + d.id() + " §7- " + d.desc());
            return true;
        }
        if (sub.equals("active")) {
            if (runs.isEmpty()) sender.sendMessage("§7Ничего не запущено.");
            for (Run r : runs.values()) {
                sender.sendMessage("§e#" + r.id + " §a" + r.def.id() + " §7масштаб " + r.s + " @ "
                        + (int) r.x + " " + (int) r.y + " " + (int) r.z);
            }
            return true;
        }
        if (sub.equals("stop")) {
            if (args.length < 2 || args[1].equalsIgnoreCase("all")) {
                stopAll();
                sender.sendMessage("§aВсе анимации остановлены.");
                return true;
            }
            try {
                stop(Integer.parseInt(args[1]));
                sender.sendMessage("§aОстановлено.");
            } catch (NumberFormatException e) {
                sender.sendMessage("§cУкажите номер или all.");
            }
            return true;
        }
        if (sub.equals("play")) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage("Только игрок может запускать анимации.");
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage("§c/mfx play <имя> [масштаб] [секунд]");
                return true;
            }
            Def d = DEFS.get(args[1].toLowerCase());
            if (d == null) {
                sender.sendMessage("§cНет такой анимации. /mfx list");
                return true;
            }
            double sc = 1;
            int sec = 600;
            try {
                if (args.length > 2) sc = Double.parseDouble(args[2]);
                if (args.length > 3) sec = Integer.parseInt(args[3]);
            } catch (NumberFormatException e) {
                sender.sendMessage("§cМасштаб и секунды должны быть числами.");
                return true;
            }
            sc = M.clamp(sc, 0.2, getConfig().getDouble("max-scale", 4.0));
            if (runs.size() >= getConfig().getInt("max-active", 5)) {
                sender.sendMessage("§cСлишком много активных анимаций. /mfx stop all");
                return true;
            }
            Location l = p.getLocation();
            int id = nextId++;
            Run r = new Run(id, d, l.getWorld(), l.getX(), l.getY(), l.getZ(), sc,
                    sec <= 0 ? Integer.MAX_VALUE : sec * 20);
            r.task = Bukkit.getScheduler().runTaskTimer(this, r, 1L, d.period());
            runs.put(id, r);
            sender.sendMessage("§aЗапущено §e" + d.id() + " §7(#" + id + ", масштаб " + sc + ")");
            return true;
        }
        sender.sendMessage("§c/mfx help");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("list", "play", "active", "stop", "help")) {
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("play")) {
            for (String s : DEFS.keySet()) if (s.startsWith(args[1].toLowerCase())) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("stop")) {
            out.add("all");
            for (Integer i : runs.keySet()) out.add(String.valueOf(i));
        } else if (args.length == 3 && args[0].equalsIgnoreCase("play")) {
            out.addAll(List.of("1", "1.5", "2"));
        } else if (args.length == 4 && args[0].equalsIgnoreCase("play")) {
            out.addAll(List.of("0", "300", "600"));
        }
        return out;
    }
}
