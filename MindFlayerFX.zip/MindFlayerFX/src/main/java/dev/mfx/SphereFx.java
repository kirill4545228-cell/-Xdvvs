package dev.mfx;

import java.util.Random;

/**
 * Невидимая точка в центре. Вокруг неё сотни зелёных и жёлтых частиц плавно текут
 * друг за другом полосками по орбитам и вместе образуют огромный шар.
 */
public final class SphereFx implements Fx {
    static final int GREEN = 0x39FF14, YELLOW = 0xFFE81F;
    static final int S = 56, N = 15;
    private final double[][] u = new double[S][], v = new double[S][];
    private final double[] om = new double[S], ph = new double[S];

    public SphereFx() {
        Random r = new Random(20261108L);
        for (int i = 0; i < S; i++) {
            double[] a = M.norm(new double[]{r.nextGaussian(), r.nextGaussian(), r.nextGaussian()});
            double[] h = Math.abs(a[0]) < 0.8 ? new double[]{1, 0, 0} : new double[]{0, 1, 0};
            u[i] = M.norm(M.cross(a, h));
            v[i] = M.cross(a, u[i]);
            om[i] = (0.014 + r.nextDouble() * 0.018) * (r.nextDouble() < 0.8 ? 1 : -1);
            ph[i] = r.nextDouble() * Math.PI * 2;
        }
    }

    @Override
    public void tick(Ctx c) {
        double R = 24 * c.s;
        c.oy = R;
        c.yaw = c.t * 0.004;
        int n = c.n(N);
        for (int i = 0; i < S; i++) {
            double th = ph[i] + om[i] * c.t;
            double sg = Math.signum(om[i]);
            int from = (i & 1) == 0 ? GREEN : YELLOW, to = (i & 1) == 0 ? YELLOW : GREEN;
            for (int j = 0; j < n; j++) {
                double a = th - sg * j * 0.05;
                double rr = R * (1 + 0.035 * Math.sin(3 * a + i + c.t * 0.01));
                double cs = Math.cos(a), sn = Math.sin(a);
                double x = rr * (u[i][0] * cs + v[i][0] * sn);
                double y = rr * (u[i][1] * cs + v[i][1] * sn);
                double z = rr * (u[i][2] * cs + v[i][2] * sn);
                c.trans(x, y, z, from, to, 3.7 - 2.4 * j / n);
            }
        }
    }
}
