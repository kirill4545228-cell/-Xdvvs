package dev.mfx;

import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.World;

/**
 * Контекст кадра. Все координаты в эффектах - локальные (относительно точки запуска).
 * force=true => частицы видны с огромного расстояния (до 512 блоков).
 */
public final class Ctx {
    public final World w;
    public final double cx, cy, cz, s, density;
    public final int t, frame;
    /** Локальный поворот вокруг Y и смещение центра (меняются самим эффектом). */
    public double yaw, ox, oy, oz;

    public Ctx(World w, double cx, double cy, double cz, double s, double density, int t, int frame) {
        this.w = w; this.cx = cx; this.cy = cy; this.cz = cz;
        this.s = s; this.density = density; this.t = t; this.frame = frame;
    }

    /** Количество элементов с учётом плотности из config.yml. */
    public int n(int base) { return Math.max(1, (int) Math.round(base * density)); }

    private void send(Particle p, double x, double y, double z, int count, double spread, double speed, Object data) {
        double cs = Math.cos(yaw), sn = Math.sin(yaw);
        double rx = x * cs + z * sn, rz = -x * sn + z * cs;
        w.spawnParticle(p, cx + rx + ox, cy + y + oy, cz + rz + oz, count, spread, spread, spread, speed, data, true);
    }

    private static float sz(double size) { return (float) M.clamp(size, 0.3, 4.0); }

    /** Одна цветная частица-пыль. */
    public void dust(double x, double y, double z, int rgb, double size) {
        send(Particle.DUST, x, y, z, 1, 0, 0, new Particle.DustOptions(Color.fromRGB(rgb & 0xFFFFFF), sz(size)));
    }

    /** Пыль, плавно меняющая цвет a -> b. */
    public void trans(double x, double y, double z, int a, int b, double size) {
        send(Particle.DUST_COLOR_TRANSITION, x, y, z, 1, 0, 0,
                new Particle.DustTransition(Color.fromRGB(a & 0xFFFFFF), Color.fromRGB(b & 0xFFFFFF), sz(size)));
    }

    /** Облачко пыли: один пакет - много частиц. */
    public void cloud(double x, double y, double z, int rgb, double size, int count, double spread) {
        send(Particle.DUST, x, y, z, count, spread, 0, new Particle.DustOptions(Color.fromRGB(rgb & 0xFFFFFF), sz(size)));
    }

    /** Любая обычная частица без данных (FLAME, END_ROD, ELECTRIC_SPARK ...). */
    public void p(Particle p, double x, double y, double z, int count, double spread, double speed) {
        send(p, x, y, z, count, spread, speed, null);
    }
}
